package com.javageeks;

public class MexicanPizza implements BakePizza, prepareDrinks {

    @Override
    public void preparePizza(String pizzaType, String... ingredients) {
        System.out.println("\tPreparing the "+pizzaType +" pizza in Mexican a Style...");
        System.out.println("\tPutting it into the oven");
        System.out.println("\tThe pizza is baked!");
        System.out.println("\tTake your pizza!\n");
    }

    @Override
    public void prepareDrink(String drinkType) {
        System.out.println("\tPreparing the "+drinkType +" pizza in Mexican a Style...");
        System.out.println("\tPutting it into the cup");
        System.out.println("\tTake your drink!\n");
    }
}
