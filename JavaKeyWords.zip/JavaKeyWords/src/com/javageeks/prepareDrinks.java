package com.javageeks;

public interface prepareDrinks {

    void prepareDrink(String drinkType);
}
