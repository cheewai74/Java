package com.javageeks;

import java.util.Random;

import static java.lang.Math.random;

public class PizzaVendingMachine {

    public void giveMePizza(){

        String[] toppings = new String[]{"Onion", "Tomato", "Cabbage"};
        String  pizzaType = "Thick Crust";
        String[] PizzaSelection = new String[]{"California", "Greek", "Mexican"};
        String[] DrinkSelection = new String[]{"Lemonade", "Mineral Water", "Tea"};

        Random rand = new Random();
        String Pizza = PizzaSelection [rand.nextInt(3)];
        String Drink = DrinkSelection [rand.nextInt(3)];

        BakePizza bakePizza ;
        prepareDrinks prepare_drinks = new MexicanPizza();

        switch (Pizza){
            case "California":
                bakePizza = new CaliforniaPizza();
                System.out.println("Customer ordered "
                        + Pizza + "Thick Crust Pizza");
                break;
            case "Greek":
                bakePizza = new GreekPizza();
                System.out.println("Customer ordered "
                        + Pizza + "Thick Crust Pizza");
                break;
            case "Mexican":
                bakePizza = new MexicanPizza();
                System.out.println("Customer ordered "
                        + Pizza + "Thick Crust Pizza and a " + Drink);
                break;
        }


    }
}
