package com.javageeks;

public class GreekPizza implements BakePizza{

    @Override
    public void preparePizza(String pizzaType, String... toppings) {
        System.out.println("\tPreparing the "+pizzaType +" pizza in Greek a Style...");
        System.out.println("\tPutting it into the oven");
        System.out.println("\tThe pizza is baked!");
        System.out.println("\tTake your pizza!\n");
    }
}
