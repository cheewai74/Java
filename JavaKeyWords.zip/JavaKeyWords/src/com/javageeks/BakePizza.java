package com.javageeks;

public interface BakePizza {

    void preparePizza(String pizzaType, String ... ingredients);

}
