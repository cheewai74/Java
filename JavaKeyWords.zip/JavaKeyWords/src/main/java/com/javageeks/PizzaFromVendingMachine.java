package main.java.com.javageeks;

import com.javageeks.PizzaVendingMachine;

public class PizzaFromVendingMachine {
    public  static void main(String[] args){
        PizzaVendingMachine pizza_from_vending_machine = new PizzaVendingMachine();
        pizza_from_vending_machine.giveMePizza();
    }
}
