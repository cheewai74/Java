package com.company;

/***
 *
 * During the execution of someMethod,
 * an object of type MyObject is created in the heap and
 * a reference to it (myObj, a local variable) is stored in the stack.
 * When someMethod terminates,
 * the reference to MyObject (myObj) goes out of scope,
 * since it is a local variable.
 * MyObject is now unreachable,
 * making it eligible for garbage collection.
 */

public class LocalObject {

    public static void main(String[] args) {
        // write your code here
        someMethod();
        System.exit(0);
    }

    static void someMethod(){
        MyObject myObj = new MyObject();
        System.out.println(myObj.sayHello());
    }
}
