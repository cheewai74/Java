package com.company;

public class ShowFileDriver {

    public static void main(String[] args) {
        try(ShowFile sFile = new ShowFile()){
            System.out.println(sFile.returnContentsOfFile());
        } catch (Exception e) {
            // Handle the exception
        }
    }

}
