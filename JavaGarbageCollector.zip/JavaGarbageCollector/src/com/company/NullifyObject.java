package com.company;

/***
 *
 * When variable myObj is assigned to null,
 * the previously assigned object
 * is no longer reachable and is eligible for CG.
 *
 */
public class NullifyObject {

    public static void main(String[] args) {
        // write your code here
        MyObject myObj = new MyObject();
        myObj.sayHello();
        myObj = null;
        myObj.sayHello();
    }

}
