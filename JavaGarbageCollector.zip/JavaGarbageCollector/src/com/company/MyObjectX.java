package com.company;

public class MyObjectX {
    OtherObject otherObj = new OtherObject();
}
