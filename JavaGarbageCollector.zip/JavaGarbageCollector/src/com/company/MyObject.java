package com.company;

public class MyObject {
    public String sayHello(){
        return "Hello";
    }
}
