package com.company;

/***
 *
 When we reinitialize the variable myObj_A
 to the object pointed to by myObj_B,
 the original object is no longer reachable
 and therefore eligible for GC.
 Also, note that any instance variable
 referenced objects of the original object
 (e.g OtherObject) are also no longer
 reachable and eligible for collection.
 */

public class ReinitObject {

    public static void main(String[] args) {
        // write your code here
        MyObjectX myObjA = new MyObjectX();
        MyObjectX myObjB = new MyObjectX();
        System.out.println(myObjA.toString());
        System.out.println(myObjB.toString());

        myObjA = myObjB;
        System.out.println(myObjA.toString());
        System.out.println(myObjB.toString());

    }
}
