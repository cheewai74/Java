package com.company;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ShowFile implements AutoCloseable {

    BufferedReader inputStream;
    public String returnContentsOfFile() throws IOException {
        inputStream = new BufferedReader(
                new FileReader(getFile("quote.txt")));
        StringBuffer output = new StringBuffer();
        String line;
        while ((line = inputStream.readLine()) != null) {
            output.append(line + "\n");
        }
        return output.toString();
    }

    private File getFile(String fileName) {
        return new File(
                this.getClass()
                        .getClassLoader()
                        .getResource(fileName)
                        .getFile());
    }
    @Override
    public void close() throws Exception {
        System.out.println("Cleaning out resources ... ");
        inputStream.close();
    }
}
