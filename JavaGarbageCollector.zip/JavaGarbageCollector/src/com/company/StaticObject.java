package com.company;

/***
 *
 * an object of type MyObject is created and
 * tied to the static variable myObj when the StaticObject class
 * is loaded into memory by the classloader.
 * MyObject remains in the heap space, even when the program
 * ends since it referenced by a static variable.
 *
 */

public class StaticObject {

    static MyObject myObj = new MyObject();

    public static void main(String[] args) {
        // write your code here
        someMethod();
        System.out.println("In Main - " +myObj.sayHello());
    }

    static void someMethod(){
        System.out.println("Some Method - " +myObj.sayHello());
    }

}


