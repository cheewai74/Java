package com.company;

public class OtherObject {
}
